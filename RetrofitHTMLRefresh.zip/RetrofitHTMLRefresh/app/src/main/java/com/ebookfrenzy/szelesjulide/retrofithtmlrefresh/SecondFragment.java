package com.ebookfrenzy.szelesjulide.retrofithtmlrefresh;

import android.app.Fragment;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import com.ebookfrenzy.szelesjulide.retrofithtmlrefresh.dataClasses.Item;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by szeles.julide on 2017/06/13.
 */

public class SecondFragment extends Fragment {

    static ArrayList<Item> itemList;
    private static CostumAdapter myAdapter;

    static Context context;
    static ListView listView;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.second_fragment,container,false);
        listView = (ListView)view.findViewById(R.id.listView1);
        context = getActivity();
        //addElementsIntoListView();
        return view;
    }

    public static void setItemListValue(ArrayList<Item> list){
        itemList = list;
    }

    public static void addElementsIntoListView(){
        myAdapter = new CostumAdapter(itemList,context);
        listView.setAdapter(myAdapter);
    }
}
