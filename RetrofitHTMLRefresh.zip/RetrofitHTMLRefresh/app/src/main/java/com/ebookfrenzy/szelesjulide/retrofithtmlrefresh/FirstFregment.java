package com.ebookfrenzy.szelesjulide.retrofithtmlrefresh;

import android.app.Fragment;
import android.app.FragmentManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.ebookfrenzy.szelesjulide.retrofithtmlrefresh.dataClasses.Item;
import com.ebookfrenzy.szelesjulide.retrofithtmlrefresh.dataClasses.SOAnswersResponse;
import com.ebookfrenzy.szelesjulide.retrofithtmlrefresh.dataClasses.remote.ApiUtils;
import com.ebookfrenzy.szelesjulide.retrofithtmlrefresh.dataClasses.remote.SOService;

import java.util.ArrayList;
import java.util.List;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by szeles.julide on 2017/06/13.
 */

public class FirstFregment extends Fragment {

    Button requestButton;
    private SOService mService;

    ArrayList<Item> generalItemList;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        //return super.onCreateView(inflater, container, savedInstanceState);
        View view = inflater.inflate(R.layout.first_fragment,container,false);

        mService = ApiUtils.getSOService();
        requestButton = (Button)view.findViewById(R.id.buttonRequestData);
        requestButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadAnswer();
            }
        });

        generalItemList = new ArrayList<Item>();


        //Download data in a background thread, (still a bit slow tough)
        AsyncTask.execute(new Runnable() {
            @Override
            public void run() {
                mService.getAnswers().enqueue(new Callback<SOAnswersResponse>() {
                    @Override
                    public void onResponse(Call<SOAnswersResponse> call, Response<SOAnswersResponse> response) {
                        SOAnswersResponse response1 = (SOAnswersResponse)response.body();
                        String stringVersion = response1.toString();
                        List<Item> tempList = response.body().getItems();
                        generalItemList = (ArrayList<Item>)tempList;
                        Toast.makeText(getActivity(),"Data has been downloaded",Toast.LENGTH_LONG).show();

                    }

                    @Override
                    public void onFailure(Call<SOAnswersResponse> call, Throwable t) {

                    }
                });
            }
        });


        return view;
    }

    private void loadAnswer() {
        FragmentManager fragmentManager = getFragmentManager();
        SecondFragment secondFragment = (SecondFragment)fragmentManager.findFragmentById(R.id.fragmentSecond);

        if (secondFragment != null && secondFragment.isInLayout()){
            SecondFragment.setItemListValue(generalItemList);
            SecondFragment.addElementsIntoListView();
        }


    }
}
